Este conjunto fue preparado desde base, desde "KA_Story_RGB_IR_DEPTH_hour".
C:\Users\Usuari\PycharmProjects\SizeEstimation\test\KA_Story_RGB_IR_DEPTH_hour_5f_mask\preprocessed_data\images
C:\Users\Usuari\PycharmProjects\SizeEstimation\test\KA_Story_RGB_IR_DEPTH_hour_5f_mask\preprocessed_data\annotations --tool rectangle --labelmap
C:\Users\Usuari\PycharmProjects\SizeEstimation\test\KA_Story_RGB_IR_DEPTH_hour_5f_mask\preprocessed_data\labelmap_apples_id.json


